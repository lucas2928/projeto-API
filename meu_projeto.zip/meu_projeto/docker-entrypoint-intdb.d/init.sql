-- create_table_and_insert.sql

-- Cria a tabela 'pessoas' caso não exista
CREATE TABLE IF NOT EXISTS pessoas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    idade INT,
    data_nascimento DATE,
    email VARCHAR(255)
);

-- Insere dados na tabela apenas se ela estiver vazia
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pessoas) THEN
        INSERT INTO pessoas (nome, idade, data_nascimento, email) VALUES
        ('Maria', 30, '1993-05-15', 'maria@example.com'),
        ('João', 25, '1998-07-22', 'joao@example.com'),
        ('Ana', 28, '1995-02-10', 'ana@example.com');
    END IF;
END $$;

