<?php
$host = 'db';
$port = '5432';
$dbname = 'meubanco';
$user = 'usuario';
$password = 'senha';

try {
    // Conexão com o banco de dados PostgreSQL
    $dsn = "pgsql:host=$host;port=$port;dbname=$dbname;";
    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    echo "<h1>Conexão com o banco de dados bem-sucedida!</h1>";

    // Verificando o banco de dados atual
    $stmt = $pdo->query("SELECT current_database();");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "<p><strong>Banco de dados atual:</strong> " . $row['current_database'] . "</p>";

    // Criação da tabela 'pessoas' caso ela não exista
    $pdo->exec("CREATE TABLE IF NOT EXISTS pessoas (
        id SERIAL PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        idade INT
    );");

    // Insere dados apenas se a tabela estiver vazia
    $pdo->exec("DO $$ 
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM pessoas) THEN
            INSERT INTO pessoas (nome, idade) VALUES
            ('Maria', 30),
            ('João', 25),
            ('Ana', 28);
        END IF;
    END $$;");

    // Exemplo: listar dados de uma tabela
    $stmt = $pdo->query("SELECT id, nome, idade FROM pessoas"); // Consultando id, nome e idade

    // Exibindo os resultados em uma tabela HTML
    if ($stmt->rowCount() > 0) {
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Nome</th><th>Idade</th></tr>"; // Cabeçalho da tabela
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
            echo "<td>" . htmlspecialchars($row['idade']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Nenhum dado encontrado na tabela.</p>";
    }

} catch (PDOException $e) {
    echo "<h1>Erro na conexão: " . $e->getMessage() . "</h1>";
}
?>
