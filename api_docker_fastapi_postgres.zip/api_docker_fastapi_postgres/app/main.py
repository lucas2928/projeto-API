from fastapi import FastAPI
import psycopg2
import os

app = FastAPI()

@app.get("/")
def read_root():
    return {"API rodando com Docker!"}

@app.get("/db-status")
def db_status():
    try:
        conn = psycopg2.connect(
            dbname=os.getenv("POSTGRES_DB"),
            user=os.getenv("POSTGRES_USER"),
            password=os.getenv("POSTGRES_PASSWORD"),
            host="db",
            port="5432"
        )
        return {"Conectado ao banco!"}
    except Exception as e:
        return {"Erro ao conectar", "error": str(e)}